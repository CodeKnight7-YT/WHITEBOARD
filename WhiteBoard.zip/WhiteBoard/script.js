const canvas = document.getElementById("whiteboard");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let isDrawing = false;
let startX, startY;
let currentTool = "pen";
let penColor = "#000000";
let penSize = 5;
let isFill = false;

const sidebar = document.getElementById("sidebar");
const toggleSidebar = document.getElementById("toggleSidebar");
const colorCircles = document.querySelectorAll(".color-circle");
const thicknessSlider = document.getElementById("thickness");

// For typing functionality
let typingMode = false;
let textInput = "";
let cursorX = 0;
let cursorY = 0;

const floatingTextArea = document.createElement("textarea");
floatingTextArea.style.position = "absolute";
floatingTextArea.style.display = "none";  // Initially hidden
floatingTextArea.style.fontFamily = "cursive";
floatingTextArea.style.fontSize = "20px";
floatingTextArea.style.backgroundColor = "transparent";
floatingTextArea.style.border = "none";
floatingTextArea.style.outline = "none";
document.body.appendChild(floatingTextArea);

// When the user clicks on the canvas, set cursor position
canvas.addEventListener("click", (e) => {
    cursorX = e.clientX;
    cursorY = e.clientY;
});

// Sidebar toggle
toggleSidebar.addEventListener("click", () => {
    sidebar.classList.toggle("open");
    toggleSidebar.textContent = sidebar.classList.contains("open") ? "⏴" : "⏵";
});

// Color selection
colorCircles.forEach((circle) => {
    circle.addEventListener("click", () => {
        penColor = circle.getAttribute("data-color");
    });
});

// Adjust thickness
thicknessSlider.addEventListener("input", (e) => {
    penSize = e.target.value;
});

// Drawing logic
canvas.addEventListener("mousedown", (e) => {
    isDrawing = true;
    startX = e.clientX;
    startY = e.clientY;
    if (currentTool === "pen" || currentTool === "eraser") {
        ctx.beginPath();
        ctx.moveTo(e.clientX, e.clientY);
    }
});

canvas.addEventListener("mousemove", (e) => {
    if (!isDrawing) return;

    if (currentTool === "pen") {
        ctx.lineTo(e.clientX, e.clientY);
        ctx.strokeStyle = penColor;
        ctx.lineWidth = penSize;
        ctx.lineCap = "round";
        ctx.stroke();
    } else if (currentTool === "eraser") {
        ctx.clearRect(e.clientX - penSize / 2, e.clientY - penSize / 2, penSize, penSize);
    }
});

canvas.addEventListener("mouseup", (e) => {
    if (!isDrawing) return;

    if (currentTool === "rectangle" || currentTool === "circle" || currentTool === "arrow" || currentTool === "line") {
        const width = e.clientX - startX;
        const height = e.clientY - startY;

        if (currentTool === "rectangle") {
            ctx.strokeStyle = penColor;
            ctx.lineWidth = penSize;
            ctx.strokeRect(startX, startY, width, height);
        } else if (currentTool === "circle") {
            ctx.beginPath();
            ctx.arc(startX, startY, Math.sqrt(width ** 2 + height ** 2), 0, Math.PI * 2);
            ctx.strokeStyle = penColor;
            ctx.lineWidth = penSize;
            ctx.stroke();
        } else if (currentTool === "line") {
            ctx.beginPath();
            ctx.moveTo(startX, startY);
            ctx.lineTo(e.clientX, e.clientY);
            ctx.strokeStyle = penColor;
            ctx.lineWidth = penSize;
            ctx.stroke();
        } else if (currentTool === "arrow") {
            drawArrow(startX, startY, e.clientX, e.clientY);
        }
    }
    isDrawing = false;
});

// Keyboard shortcuts
document.addEventListener("keydown", (e) => {
    // Prevent "S" key from triggering save if in typing mode
    if (typingMode) {
        return; // Do nothing if the user is typing
    }

    // Trigger typing mode on Control or Command key
    if ((e.key === "Control" || e.key === "Meta") && !typingMode) {
        typingMode = true;
        floatingTextArea.style.display = "block";  // Show text area
        floatingTextArea.style.left = `${cursorX}px`;
        floatingTextArea.style.top = `${cursorY}px`;
        floatingTextArea.focus();  // Focus on the text area to type
    }

    switch (e.key.toLowerCase()) {
        case "b":
            currentTool = "pen";
            break;
        case "r":
            currentTool = "rectangle";
            break;
        case "c":
            currentTool = "circle";
            break;
        case "a":
            currentTool = "arrow";
            break;
        case "l":
            currentTool = "line";
            break;
        case "e":
            currentTool = "eraser";
            break;
        case "d":
            document.body.classList.add("dark-mode");
            break;
        case "w":
            document.body.classList.remove("dark-mode");
            break;
        case "s":
            if (!typingMode) {
                saveImage();
            }
            break;
        case "escape":
            clearCanvas();
            break;
    }
});


// Detect when the user types in the text area
floatingTextArea.addEventListener("input", (e) => {
    textInput = e.target.value;
});

// When the user presses Enter, draw text on the canvas
floatingTextArea.addEventListener("blur", () => {
    ctx.clearRect(cursorX, cursorY - 20, canvas.width, 30);  // Clear previous text
    ctx.font = "20px cursive";
    ctx.fillStyle = penColor;
    ctx.fillText(textInput, cursorX, cursorY);
    textInput = "";  // Reset the input
    floatingTextArea.value = "";  // Clear textarea
    floatingTextArea.style.display = "none";  // Hide the textarea
    typingMode = false;  // End typing mode
});

// Function to clear the canvas and reset everything
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    textInput = "";
    floatingTextArea.style.display = "none";  // Hide the text input area
    typingMode = false;
}

// Function to save the whiteboard as an image
function saveImage() {
    const link = document.createElement("a");
    link.download = "whiteboard.png";
    link.href = canvas.toDataURL();
    link.click();
}

// Function to draw an arrow on the canvas
function drawArrow(fromX, fromY, toX, toY) {
    const headLength = 15; // Arrowhead length
    const angle = Math.atan2(toY - fromY, toX - fromX);
    ctx.beginPath();
    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.lineTo(toX - headLength * Math.cos(angle - Math.PI / 6), toY - headLength * Math.sin(angle - Math.PI / 6));
    ctx.moveTo(toX, toY);
    ctx.lineTo(toX - headLength * Math.cos(angle + Math.PI / 6), toY - headLength * Math.sin(angle + Math.PI / 6));
    ctx.strokeStyle = penColor;
    ctx.lineWidth = penSize;
    ctx.stroke();
}
